import os
import random
from colorama import Fore  # Colors
import colorama
import time
colorama.init()

Mtoken = input("""
Disclaimer: There is no guarantee that you will receive tokens there are working. There's a chance, but it's not a guarantee
               
How much Token do you want to generate: """)

char = "qwertyuiopasdfghjklzxvcbnm1234567890QWERTYUIOPASDFGHJKLZXCVBNM"

valid = 0
invalid = 0
error = 0

# title

def titleGC():
    os.system("Token gen/checker - Valid: " + str(valid) + " Invalid: " + str(invalid) + " Error: " + str(error))


# Generator

with open("input/3m_tokens.txt", "w") as output:
    for i in range(int(Mtoken)):
        fir = "".join((random.choice(char) for i in range(26)))
        sec = "".join((random.choice(char) for i in range(6)))
        endG = "".join((random.choice(char) for i in range(38)))
        result = fir + "." + sec + "." + endG
        output.write(result + "\n")
        print(f"" + result)
        print(end="\r" + "Pls wait short that takes some seconds")
        print(end="\r" + "Token Generator: " + str(i))

