import discord
import asyncio

clients = []

async def send_message(client, target_user_id, message_content):
    try:
        user = await client.fetch_user(target_user_id)
        await user.send(message_content)
        print(f"Message sent to {user.name}#{user.discriminator}")
    except discord.errors.Forbidden:
        print(f"Unable to send a message to {user.name}#{user.discriminator}. The user may have blocked the bot or disabled direct messages.")
    except discord.NotFound:
        print(f"User with ID {target_user_id} not found.")
    except Exception as e:
        print(f"An error occurred while sending a message: {e}")

async def on_ready():
    num_tokens = len(clients)
    print(f"We have logged in {num_tokens}/{num_tokens} tokens")  # Print the total number of tokens

async def main():
    global clients  # Declare clients as global so it can be accessed in on_ready function

    tokens_file = "temp/tokenspammer.txt"

    try:
        with open(tokens_file, "r") as f:
            tokens = f.read().splitlines()

        if not tokens:
            print("No tokens found in tokenspammer.txt. Please add each bot token on a new line to the file and try again.")
            return

        for bot_token in tokens:
            client = discord.Client()
            client.event(on_ready)
            await client.start(bot_token)
            clients.append(client)

        for client in clients:
            await client.wait_until_ready()  # Wait for all clients to be ready

        while True:
            choice = input("What do you want next? Enter the number of your choice:\n1. Send messages to user\n2. log out\n")

            if choice == "2":
                for client in clients:
                    await client.logout()
                print("Logged out.")
                break

            elif choice == "1":
                target_user_id = int(input("Enter the target user's ID: "))
                message_content = input("Enter the message content: ")

                # Start sending messages to the target user for all logged in clients
                for client in clients:
                    await send_message(client, target_user_id, message_content)

    except FileNotFoundError:
        print(f"File not found. Please make sure that the file {tokens_file} exists in the temp folder.")

if __name__ == "__main__":
    asyncio.run(main())
