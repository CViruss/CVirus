import socket
import requests

def get_client_ip():
    try:
        sock = socket.create_connection(("www.google.com", 80))
        ip_address = sock.getsockname()[0]
        sock.close()
        return ip_address
    except Exception as e:
        return str(e)

def send_ip(ip_address):
    # Example code using the 'requests' library to send the IP address to the other website
    data = {"ip_address": ip_address}
    try:
        response = requests.post("https://goooglee.glitch.me", json=data)
        response.raise_for_status()
        print("IP address sent successfully.")
    except requests.exceptions.RequestException as e:
        print("Error sending IP address:", e)

def main():
    client_ips = []

    print("Welcome!")
    print("What would you like to do?")
    print("1. Show my IP address")
    print("2. Show the IP address of the person who clicked on the website")

    choice = input("Enter the number of your choice (1 or 2): ")

    if choice == "1":
        client_ip = get_client_ip()
        print("Your IP address is:", client_ip)
    elif choice == "2":
        if client_ips:
            print("IP address of the person who clicked on the website:", client_ips[-1])
            print("Please click on this website to send the IP address: https://goooglee.glitch.me")
            send_ip(client_ips[-1])
        else:
            print("No IP address has been sent yet.")
    else:
        print("Invalid choice. Please choose 1 or 2.")

if __name__ == "__main__":
    main()
