import requests
import os

WEBHOOK_URL = input("Gib die Discord Webhook-URL ein: ")
CHANNEL_ID = input("Gib die ID des Ziel-Channels ein: ")
USERNAME = input("Gib den Benutzernamen ein: ")
PASSWORD = input("Gib das Passwort ein: ")
EMAIL = input("Gib die Email ein: ")
IMAGE_URL = input("Gib die Bild-URL ein: ")

def send_embed(webhook_url, channel_id, username, password, email, image_url):
    embed = {
        'title': 'Zugangsdaten',
        'color': 0x00ff00,
        'fields': [
            {'name': 'Username', 'value': username},
            {'name': 'Passwort', 'value': password},
            {'name': 'Email', 'value': email}
        ],
        'image': {'url': image_url}
    }

    data = {
        'content': f'<@{channel_id}>',
        'embeds': [embed]
    }

    response = requests.post(webhook_url, json=data)
    print(response.status_code)

# Aufruf mit den eingegebenen Informationen
send_embed(WEBHOOK_URL, CHANNEL_ID, USERNAME, PASSWORD, EMAIL, IMAGE_URL)
